use strict;
use vars qw($VERSION %IRSSI);
use Irssi;
use Irssi::Irc;

# Usage:
# /script load go.pl
# If you are in #irssi you can type /go #irssi or /go irssi or even /go ir ...
# also try /go ir<tab> and /go  <tab> (that's two spaces)

$VERSION = '1.00';

%IRSSI = (
    authors     => 'nohar',
    contact     => 'nohar@freenode',
    name        => 'go to window',
    description => 'Implements /go command that activates a window given a name/partial name. It features a nice completion.',
    license     => 'GPLv2 or later',
    changed     => '08-17-04'
);

sub generate_the_list {
  my $foo = {};
  foreach(Irssi::windows) {
    $foo->{get_channel_name($_)} ||= 0;
    $foo->{get_channel_name($_)} += 1;
  }
  return $foo;
}

sub get_server_tag {
  my $w = shift;
  if(defined($w->items()) && defined($w->items()->{server}) && defined($w->items()->{server}->{tag})) {
    return $w->items()->{server}->{tag};
  } else {
    return "";
  }
}

sub get_channel_name {
  my $w = shift;
  return $w->get_active_name();
}

sub get_channel_and_tag {
  my $w = shift;
  if(length(get_server_tag($w)) > 0) {
    return get_channel_name($w) . '@' . get_server_tag($w);
  } else {
    return get_channel_name($w); # dunno how to handle this correctly...hopefully it will never come up.
  }
}

sub name_of_this_window {
  my $w = shift;
  my $list = generate_the_list();
  if($list->{get_channel_name($w)} > 1){
    return get_channel_and_tag($w);
  } else {
    return get_channel_name($w);
  }
}

sub signal_complete_go {
	my ($complist, $window, $word, $linestart, $want_space) = @_;
	my $channel = $window->get_active_name();
	my $k = Irssi::parse_special('$k');

        return unless ($linestart =~ /^\Q${k}\Ego/i);

	@$complist = ();
	foreach my $w (Irssi::windows) {
		my $name = name_of_this_window($w);
		if ($word ne "") {
			if ($name =~ /\Q${word}\E/i) {
				push(@$complist, $name)
			}
		} else {
			push(@$complist, $name);
		}
	}
	Irssi::signal_stop();
};

sub cmd_go
{
	my($chan,$server,$witem) = @_;

	$chan =~ s/ *//g;
        # try an exact match first ... this fixes when there are cases
        # like a channel called #foo and #foobar, #foobar is above
        # #foo in irssi's list, and the user types in #foo. before
        # they would have ended up at #foobar instead of #foo. now
        # they will end up at #foo.
	foreach my $w (Irssi::windows) {
		my $name = name_of_this_window($w);
		if ($name =~ /^#?\Q${chan}\E$/) {
			$w->set_active();
			return;
		}
	}
	foreach my $w (Irssi::windows) {
		my $name = name_of_this_window($w);
		if ($name =~ /^#?\Q${chan}\E/) {
			$w->set_active();
			return;
		}
	}
}

Irssi::command_bind("go", "cmd_go");
Irssi::signal_add_first('complete word', 'signal_complete_go');

