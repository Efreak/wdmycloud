/*
 * Translates for strings
 *
 */

// Add
const STR_WINDOW_ADD_NAME = "[% gettext('Add new torrent') %]";
// Action
// Index
// List
// Panel
const STR_NO_SELECTED     = "[% gettext('No current torrent selected') %]";
// Prop
